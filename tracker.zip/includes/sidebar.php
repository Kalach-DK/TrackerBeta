<div class="tracker-sidebar">
  <div class="brand">Tracker</div>
  <nav>
    <a href="/tracker/index.php" class="nav-link">Dashboard</a>
    <a href="/tracker/offers.php" class="nav-link">Offers</a>
    <a href="/tracker/campaigns.php" class="nav-link">Campaigns</a>
    <a href="/tracker/affiliate_programs.php" class="nav-link">Affiliate Programs</a>
    <a href="/tracker/traffic_sources.php" class="nav-link">Traffic Sources</a>
    <a href="/tracker/clicks.php" class="nav-link">Clcik Report</a>
  </nav>
</div>